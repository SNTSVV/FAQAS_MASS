#!/bin/bash

HOME=/home/mlfs
TST_FOLDER=$HOME/results

MUTANTS_FOLDER=/opt/mutations/src-mutants

PYTHON=/usr/local/bin/python3.7

prioritize=/opt/srcirorfaqas/FAQASOptimizations/FAQASPrioritization/ONLY_PRIORITIZE/prioritize.sh

strategy=$1
method=$2
casestudy="mlfs"

for mutant in `find $MUTANTS_FOLDER -name '*.c'`;do
    lines=`cat $mutant | wc -l`
    count=1

    echo $mutant

    for lineIt in `seq $count $lines`;do
        echo source $prioritize $PYTHON $TST_FOLDER $strategy $method $MUTANTS_FOLDER $mutant $lineIt $casestudy
        source $prioritize $PYTHON $TST_FOLDER $strategy $method $MUTANTS_FOLDER $mutant $lineIt $casestudy
    done
done  


